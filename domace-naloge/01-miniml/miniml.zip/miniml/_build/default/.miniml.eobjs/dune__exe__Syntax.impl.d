syntax.ml: List
