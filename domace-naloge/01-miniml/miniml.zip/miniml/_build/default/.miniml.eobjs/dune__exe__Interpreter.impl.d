interpreter.ml: Syntax
