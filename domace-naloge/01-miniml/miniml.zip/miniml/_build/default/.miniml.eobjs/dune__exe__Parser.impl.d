parser.ml: List String Syntax
