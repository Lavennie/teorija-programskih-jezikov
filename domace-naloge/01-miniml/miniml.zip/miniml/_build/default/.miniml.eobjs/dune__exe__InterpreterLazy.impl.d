interpreterLazy.ml: Syntax
